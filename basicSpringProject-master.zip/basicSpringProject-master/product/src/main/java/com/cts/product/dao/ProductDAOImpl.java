package com.cts.product.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.cts.product.bean.Product;
import com.cts.product.util.HibernateUtil;

@Repository("productDAO")
public class ProductDAOImpl implements ProductDAO{

	public String addProduct(Product product) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = null;
		Transaction transaction = null;
		try{
			session = sessionFactory.openSession();
			transaction = session.getTransaction();
			transaction.begin();
			session.save(product);
			transaction.commit();
			return "true";
		} catch(Exception e){
			if(transaction!=null){
				transaction.rollback();
			}
			e.printStackTrace();
			return "false";
		} finally{
			if(session!=null){
				session.close();
			}
		}
	}

	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	public Product findProduct(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public String deleteProduct(String productId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Product> filterProducts(String query) {
		// TODO Auto-generated method stub
		return null;
	}

}
