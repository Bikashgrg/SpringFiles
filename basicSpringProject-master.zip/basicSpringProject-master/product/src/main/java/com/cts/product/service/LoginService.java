package com.cts.product.service;

import com.cts.product.bean.Login;

public interface LoginService {
	public boolean authentication(Login user);
}
