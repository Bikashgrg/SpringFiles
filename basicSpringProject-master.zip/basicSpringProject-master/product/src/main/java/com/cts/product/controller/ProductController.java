package com.cts.product.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.product.bean.Product;

@Controller
public class ProductController {
	@RequestMapping("product.html")
	public String getProductPage(){
		return "product";
	}
	@RequestMapping(value="product.html", method=RequestMethod.POST)
	public ModelAndView addProduct(@ModelAttribute Product product){
		ModelAndView modelAndview = new ModelAndView();
		modelAndview.setViewName("productAdded");
		return modelAndview;
	}
}
