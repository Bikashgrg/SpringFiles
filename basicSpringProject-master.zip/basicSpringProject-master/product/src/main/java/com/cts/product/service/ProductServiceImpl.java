package com.cts.product.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.product.dao.ProductDAO;


@Service("productService")
public class ProductServiceImpl{
	@Autowired
	private ProductDAO productDAO;

}
