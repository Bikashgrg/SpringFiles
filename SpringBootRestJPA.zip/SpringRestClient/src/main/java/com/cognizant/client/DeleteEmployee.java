package com.cognizant.client;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

public class DeleteEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		String url = "http://localhost:8087/employee/delete/{empId}";
		RestTemplate template = new RestTemplate();
		template.delete(url, 101);

	}

}
