package com.cognizant.client;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.cognizant.entity.Employee;

public class UpdateEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		Employee employee = new Employee();
		employee.setEmpId(101);
		employee.setEmpName("Bilash");
		employee.setEmpSalary(45000);
		employee.setEmpDesignation("Worker");
		
		HttpEntity<Employee> requestEntity = new HttpEntity<Employee>(employee,headers);
		String url = "http://localhost:8087/employee/update";
		
		RestTemplate template = new RestTemplate();
		template.put(url, requestEntity);

	}

}
